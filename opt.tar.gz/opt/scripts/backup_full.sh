
if [ "$1" == "-help" ] ; then

    echo "=========================================================="

    echo " USO DEL SCRIPT DE BACKUP"

    echo "=========================================================="

    echo " Sintaxis: $0 [ORIGEN] [DESTINO]"

    echo " Ejemplo:  $0 /var/log /backup_dir"

    echo ""

    echo " Este script comprime el directorio ORIGEN y lo guarda en"

    echo " el directorio DESTINO incluyendo la fecha actual en el nombre."

    echo "=========================================================="

    exit 0

fi

if [ "$#" -ne 2 ]; then

    echo "Error: Argumentos incorrectos."

    echo "Usa '$0 -help' para ver la guía de uso."

    exit 1

fi



ORIGEN=$1

DESTINO=$2





if [ ! -d "$ORIGEN" ]; then

    echo "Error:'$ORIGEN' no existe o no está disponible."

    exit 1

fi



if [ ! -d "$DESTINO" ] || [ ! -w "$DESTINO" ]; then

    echo "Error:'$DESTINO' no existe, no está montado o no es escribible."

    exit 1

fi




FECHA=$(date +%Y%m%d)



NOMBRE_BASE=$(basename "$ORIGEN")

NOMBRE_ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"



RUTA_COMPLETA="$DESTINO/$NOMBRE_ARCHIVO"



echo "Iniciando backup de '$ORIGEN'..."


tar -czf "$RUTA_COMPLETA" "$ORIGEN" 2>/dev/null



if [ $? -eq 0 ]; then

    echo "ÉXITO: Backup guardado en -> $RUTA_COMPLETA"

else

    echo "ERROR: Falló la creación del backup."

    exit 1

fi
