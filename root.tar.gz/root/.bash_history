echo "TPServer" > /etc/hostname
shutdown now
clear
cat /etc/debian_version
apt update
apt upgrade
apt update
clear
apt update
apt full-upgrade
clear
cd /etc/apt
ls
vim sources.list
vim sources.list
clear
vim sources.list
ls
vim sources.list
clear
vim sources.list
cd ..
cd ..
clear
apt update
apt full-upgrade
cd /etc/apt
vim sources.list
clear
cd..
cd ..
cd ..
clear
apt update
apt full-upgrade
clear
cat etc/debian_version
clear
apt search nano
apt install nano
apt search ssh
apt install ssh
clear
apt install openssh_server
apt install openssh-server
cd /etc/ssh
clear
ls
cd ..
cd ..
ls -la
ls -la /root
cd /root/ssh
cd /root/.ssh
ls
ls -la
clear
cd/ etc/ssh
cd /etc/ssh
nano sshd_config
clear
cd ..
cd ..
cd root/.ssh
ls
ls -la
nano authorized_keys
clear
ls
ls -la
clear
nano authorized-keys
nano authorized_keys
cd ..
cd /etc
nano ssh_config
ls
cd ssh
clear
nano ssh_config
clear
restart ssh
systemctl restart ssh
system ctl restart sshd
systemctl restart sshd
nano ssh_config
clear
shuwdown now
shutdown now
ip a
cd etc/ssh
cd etc/.ssh
cd /etc/ssh
nano ssh_config
cd ..
cd ..
ls -la
cd /root
ls -la
cat bashrc
cat .bashrc
ls -la
root/.ssh
cd root/.ssh
ls -la
ls -la /root/.ssh
shutdown now
clear
ip a
shutdown now
cd .ssh
ls
ls -la
nano authorized_keys
ls -la
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
ls -la
apt search apache
apt search apache| more
clear
apt install apache2
clear
apt install mariadb-server php libapache2-mod-php php-mysql
clear
scp -r C:\Users\Lucas\OneDrive\Escritorio\Computacion root@TPServer: /root
scp -r C:\Users\Lucas\OneDrive\Escritorio\Computacion root@192.168.2.116: /root
scp -r C:\Users\Lucas\OneDrive\Escritorio\Computacion root@192.168.2.116:/root
scp -r "C:\Users\Lucas\OneDrive\Escritorio\Computacion" root@192.168.2.116:/root
scp -r "C:/Users/Lucas/OneDrive/Escritorio/Computacion" root@192.168.2.116:/root
ls
ls /Computacion
ls Computacion
cd computacion
cd Computacion
mv db.sql ..
ls
mv index.php ..
mv logo.png ..
ls
cd ..
rm Computacion
rmdir Computacion
ls
ls -la
mysql -u root -p
mysql -u root -p up < root/db.sql
mysql -u root -p up < db.sql
mysql -u root -p
ls -la
mysql -u root -p
mysql -u root -p db < db.sql
mysql -u root -p
mysql -u root -p db < /root/db.sql 
mysql -u root -p db </root/db.sql
mysql -u root -p 
mysql -u root -p 
clear
nano /etc/ssh/ssh_config
ip a
nano /etc/network/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
ip a
systemctl restart interfaces
systemctl restart networking
ip a
logout
ip a
clear
cd /etc
cd /ssh
cd /.ssh
cd ssh
nano sshd_config
clear
systemctl restart ssh
systemctl enable  --now ssh
ip a
cd ..
cd ..
nano /etc/network/interfaces
clear
ip a
shutdown now
clear
ls /porc
ls /proc
cat /proc/partitions 
clear
fdisk -l
log out
ip a
nano 7etc/network/interfaces
clear
nano /etc/network/interfaces
clear
systemctl restart networking
ip a
shutdown now
cd dev/sdb
cd ..
cd dev/sdb
fdisk -l  /dev/sdb
fdisk -l sdb
fdisk -l
lsblk
shurdown now
shutdown now
clear
lsblk
fdisk /dev/sdb
clear
fdisk /dev/sdb
fdisk / dev/sdc
fdisk /dev/sdc
fdisk /dev/sdc
fdisk /dev/sdc
lsblk
fdisk /dev/sdc
lsblk
gdisk /dev/ss1
gdisk /dev/sdc1
apt install gdisk
gdisk /dev/sdc1
apt update
apt install gdisk
gdisk /dev/sdc1
--fix-missing 
apt install gdisk --fix-missing
lsblk -f
e2label
e2label /dev/sdc1 "/www_dir"
parted /dev/sdc
umount /dev/sdc1
e2label /dev/sdc1 /www_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc1 "/www_dir"
mkdir www_dir
mount /dev/sdc1 "/www_dir"
mount /dev/sdc1 /www_dir
ls
mkfs.ext4 /dev/sdc1
mkfs
mkfs -t ext4 /dev/sdc1
fdisk sdc1
fdisk /dev/sdc1
lsblk 
lsblk -lf
ls
mount /dev/sdc1 /mnt
umount /dev/sdc1 /mnt
cd /mnt
ls
ls -la
cd. .
cd ..
cd wwwdir
ls
cd ..
ls -la
cd dev
ls
ls -l
cd ..
mkdir www_dir
ls
cd www_dir
mount /dev/sdc1
mount /dev/sdc1 www_dir
mount /dev/sdc1 /www_dir
umount /dev/sdc1 /www_dir
umount /dev/sdc1 
cd ..
mkfs.ext4 -L "www_dir" /dev/sdc1
partprobe
lsblk
lsblk -f
mkfs.ext4/dev/sdc1
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc
shutdown now
clear
lsblk -f
mkfs.ext4 /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mount /dev/sdc1 /www_dir
mkdir backup_dir
mount /dev/sdc2 /backup_dir
ls www_dir
ls -la www_dir
ls -la /dev
find www_dir
ls -la
ls /root
la /root/www_dir
ls /root/www_dir
ls -la /root/www_dir
rm www_dir
rmdir www_dir
rmdir /root/www_dir
cd ..
ls
lsblk -f
ls -la /dev
ls
rmdir www_dir
find backup_dir
mkdir backup_dir
mount /dev/sdc2 /backup_dir
lsblk -f
ls /etc/apache
ls etc/apache2
cat etc/apache2
cat etc/apache2.conf
cat apache2.conf
cat etc/apache2/apache2.conf
ls -la etc/apache2
ls -la etc/apache2/sites-available
nano etc/apache2/sites-available/000-defalut.conf
nano etc/apache2/sites-available/000-default.conf
nano etc/apache2/apache2.conf
cp /root/index.php logo.png
cp /root/index.php logo.png /www_dir
ls www-dir
ls www_dir
systemctl restart apache2
nano /etc/fstab
nano index
nano /www_dir/index.php
systemctl restart apache2
nano /www_dir/index.php
systemctl restart apache2
nano /www_dir/index.php
systemctl restart apache2
nano /www_dir/index.php
systemctl restart apache2
nano /www_dir/index.php
systemctl restart apache2
nano /www_dir/index.php
systemctl restart apache2
nano /www_dir/index.php
systemctl restart apache2
nano /www_dir/index.php
systemctl restart apache2
nano /www_dir/index.php
nano /www_dir/index.php
systemctl restart apache2
ls
ls -la
ls -la www_dir
chmod 666 /www_dir/logo.png
ls -la /www_dir/logo.png
./logo.png
chmod 777 /www_dir/logo.png
./logo.png
sudo ./logo.png
file logo.png
cat /www_dir/logo.png
nano /www_dir/logo.png
systemctl restart apache2
./logo.png
cat /root/logo.png
mv www_dir/logo.png
rm www_dir/logo.png
mv /root/logo.png www_dir
ls -la
systemctl restart apache2
ls -la www_dir
nano /www_dir/logo.png
nano /www_dir/index.php
nano /www_dir/index.php
systemctl restart apache2
nano /www_dir/index.php
nano /www_dir/index.php
systemctl restart apache2
clear
nano /etc/fstab
lsblk -f
nano /etc/fstab
sudo mount -a
def -h
df -h
log out
shutdown now
df -h
lsblk -f
systemctl enable --now ssh
nano etc/fsetup
nano etc/fstab
nano /etc/fstab
shutdown now
df -h
cat /proc/partitions > /opt/particion
cat opt/particion
clear
cd opt
find opt
find /opt
cd ..
cd /opt
ls
cat particion
cat /proc/partitions > /opt/particion
cat opt/particion
cat /opt/particion
shutdown now
ip -a
cd..
cd ..
ip -a
ip a
shutdown now
clear
clear
ls
ls Material_Adicional_TPVMCA.tar.gz
ls -la Material_Adicional_TPVMCA.tar.gz
tar -x Material_Adicional_TPVMCA.tar.gz
tar -xzf Material_Adicional_TPVMCA.tar.gz
ls
ls -la Material_Adicional_TPVMCA.tar.gz
ls -la Material_Adicional_TPVMCA
clear
nano /opt/scripts/backup_full.sh
mkdir /opt/scripts
ls opt
ls -la/opt
ls -la /opt
nano /opt/scripts/backup_full.sh
ls -la /opt/scripts
/opt/scripts/backup_full.sh -help
nano /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
cd opt/scripts
cd /opt/scripts
./backup_full.sh -help
chmod x backup_full.sh
chmod -x backup_full.sh
ls -l
chmod +x backup_full.sh
ls -l
./backup_full.sh -help
./backup_full.sh /var/log /backup_dir
cd ..
cd ..
ls /backup_dir
nano /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
./backup_full.sh /var/log /backup_dir
./backup_full.sh -help
cd /opt/scripts
./backup_full.sh -help
./backup_full.sh /var/log /backup_dir
crontab -e
nano crontab -e
crontab -e nano
crontab -e
nano /etc/crontab -e
ls -l  /www_dir
ls -l  /backup_dir
ls -l  backup_dir
nano /etc/crontab -e
ls -l  /backup_dir
ls -l  /backup_dir
systemctl restart cron
ls -l  /backup_dir
systemctl restart cron.service
systemctl status cron.service
nano /etc/crontab -e
systemctl restart cron.service
systemctl restart cron
systemctl status cron.service
nano /etc/crontab -e
systemctl status cron.service
nano /etc/crontab -e
systemctl status cron.service
systemctl restart cron
systemctl restart cron.service
systemctl status cron.service
ls -l  /backup_dir
nano /etc/crontab -e
systemctl restart cron.service
systemctl restart cron
systemctl status cron.service
nano /etc/crontab -e
systemctl restart cron
systemctl restart cron.service
systemctl status cron.service
ls -l  /backup_dir
nano /etc/crontab -e
systemctl restart cron.service
systemctl status cron.service
chmod 722 backup_full.sh
ls -l
cd ..
cd ..
shurdown now
shutdown now
